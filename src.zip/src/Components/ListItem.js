import React, { Component } from 'react';

class ListItem extends Component {
    render() {
        return (
            <div className='ListItem'>
                <h2>List Item</h2>
            </div>
        )
    }
}
export default ListItem;